# FCM Python API

## Overview
Simple Flask API to send push notifications using Firebase Cloud Messaging.

## Setup

1. Install dependencies:
```
pip install -r requirements.txt
```

2. Add your Firebase service account file:
- serviceAccountKey.json

3. Run the server:
```
python app.py
```

## API Endpoint
POST /send

## Example Request
```
curl -X POST http://localhost:5000/send \
-H "Content-Type: application/json" \
-d '{
  "token": "DEVICE_FCM_TOKEN",
  "title": "Hello",
  "body": "Test notification"
}'
```
