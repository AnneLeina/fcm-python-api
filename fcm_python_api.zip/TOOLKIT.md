# Firebase Cloud Messaging Toolkit (Python)

## Overview
FCM allows sending push notifications to devices via backend services.

## Setup Steps
1. Create Firebase project
2. Generate service account key
3. Install dependencies
4. Run Flask API

## Minimal Example
See app.py

## Common Errors
- Invalid token → regenerate token
- Missing JSON → ensure file exists

## References
https://firebase.google.com/docs/cloud-messaging
